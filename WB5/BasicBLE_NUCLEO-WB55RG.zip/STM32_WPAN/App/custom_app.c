/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    App/custom_app.c
  * @author  MCD Application Team
  * @brief   Custom Example Application (Server)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "app_common.h"
#include "dbg_trace.h"
#include "ble.h"
#include "custom_app.h"
#include "custom_stm.h"
#include "stm32_seq.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef struct
{
  /* Nordic_UART_Service */
  uint8_t               Tx_Notification_Status;
  /* USER CODE BEGIN CUSTOM_APP_Context_t */

  /* USER CODE END CUSTOM_APP_Context_t */

  uint16_t              ConnectionHandle;
} Custom_App_Context_t;

/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private defines ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macros -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/**
 * START of Section BLE_APP_CONTEXT
 */

static Custom_App_Context_t Custom_App_Context;

/**
 * END of Section BLE_APP_CONTEXT
 */

uint8_t UpdateCharData[247];
uint8_t NotifyCharData[247];

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* Nordic_UART_Service */
static void Custom_Tx_Update_Char(void);
static void Custom_Tx_Send_Notification(void);

/* USER CODE BEGIN PFP */
static void ParseGuioMsg(const char* msg);
/* USER CODE END PFP */

/* Functions Definition ------------------------------------------------------*/
void Custom_STM_App_Notification(Custom_STM_App_Notification_evt_t *pNotification)
{
  /* USER CODE BEGIN CUSTOM_STM_App_Notification_1 */

  /* USER CODE END CUSTOM_STM_App_Notification_1 */
  switch (pNotification->Custom_Evt_Opcode)
  {
    /* USER CODE BEGIN CUSTOM_STM_App_Notification_Custom_Evt_Opcode */

    /* USER CODE END CUSTOM_STM_App_Notification_Custom_Evt_Opcode */

    /* Nordic_UART_Service */
    case CUSTOM_STM_RX_WRITE_EVT:
      /* USER CODE BEGIN CUSTOM_STM_RX_WRITE_EVT */
      pNotification->DataTransfered.pPayload[pNotification->DataTransfered.Length] = '\0';
      ParseGuioMsg((const char*)pNotification->DataTransfered.pPayload);
      /* USER CODE END CUSTOM_STM_RX_WRITE_EVT */
      break;

    case CUSTOM_STM_TX_NOTIFY_ENABLED_EVT:
      /* USER CODE BEGIN CUSTOM_STM_TX_NOTIFY_ENABLED_EVT */
      DebugOutput("BLE notifications enabled!\r\n");
      /* USER CODE END CUSTOM_STM_TX_NOTIFY_ENABLED_EVT */
      break;

    case CUSTOM_STM_TX_NOTIFY_DISABLED_EVT:
      /* USER CODE BEGIN CUSTOM_STM_TX_NOTIFY_DISABLED_EVT */
      DebugOutput("BLE notifications disabled!\r\n");
      /* USER CODE END CUSTOM_STM_TX_NOTIFY_DISABLED_EVT */
      break;

    default:
      /* USER CODE BEGIN CUSTOM_STM_App_Notification_default */

      /* USER CODE END CUSTOM_STM_App_Notification_default */
      break;
  }
  /* USER CODE BEGIN CUSTOM_STM_App_Notification_2 */

  /* USER CODE END CUSTOM_STM_App_Notification_2 */
  return;
}

void Custom_APP_Notification(Custom_App_ConnHandle_Not_evt_t *pNotification)
{
  /* USER CODE BEGIN CUSTOM_APP_Notification_1 */

  /* USER CODE END CUSTOM_APP_Notification_1 */

  switch (pNotification->Custom_Evt_Opcode)
  {
    /* USER CODE BEGIN CUSTOM_APP_Notification_Custom_Evt_Opcode */

    /* USER CODE END P2PS_CUSTOM_Notification_Custom_Evt_Opcode */
    case CUSTOM_CONN_HANDLE_EVT :
      /* USER CODE BEGIN CUSTOM_CONN_HANDLE_EVT */
      DebugOutput("BLE connected!\r\n");
      /* USER CODE END CUSTOM_CONN_HANDLE_EVT */
      break;

    case CUSTOM_DISCON_HANDLE_EVT :
      /* USER CODE BEGIN CUSTOM_DISCON_HANDLE_EVT */
      DebugOutput("BLE disconnected!\r\n");
      /* USER CODE END CUSTOM_DISCON_HANDLE_EVT */
      break;

    default:
      /* USER CODE BEGIN CUSTOM_APP_Notification_default */

      /* USER CODE END CUSTOM_APP_Notification_default */
      break;
  }

  /* USER CODE BEGIN CUSTOM_APP_Notification_2 */

  /* USER CODE END CUSTOM_APP_Notification_2 */

  return;
}

void Custom_APP_Init(void)
{
  /* USER CODE BEGIN CUSTOM_APP_Init */

  /* USER CODE END CUSTOM_APP_Init */
  return;
}

/* USER CODE BEGIN FD */

/* USER CODE END FD */

/*************************************************************
 *
 * LOCAL FUNCTIONS
 *
 *************************************************************/

/* Nordic_UART_Service */
void Custom_Tx_Update_Char(void) /* Property Read */
{
  uint8_t updateflag = 0;

  /* USER CODE BEGIN Tx_UC_1*/

  /* USER CODE END Tx_UC_1*/

  if (updateflag != 0)
  {
    Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t *)UpdateCharData);
  }

  /* USER CODE BEGIN Tx_UC_Last*/

  /* USER CODE END Tx_UC_Last*/
  return;
}

void Custom_Tx_Send_Notification(void) /* Property Notification */
{
  uint8_t updateflag = 0;

  /* USER CODE BEGIN Tx_NS_1*/

  /* USER CODE END Tx_NS_1*/

  if (updateflag != 0)
  {
    Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t *)NotifyCharData);
  }

  /* USER CODE BEGIN Tx_NS_Last*/

  /* USER CODE END Tx_NS_Last*/

  return;
}

/* USER CODE BEGIN FD_LOCAL_FUNCTIONS*/
void ParseGuioMsg(const char* msg) {
	static const char* initStr = "@init";
	static const char* lightOffStr = "@light_off";
	static const char* lightOnStr = "@light_on";
	static const char* brightnessStr = "@brightness";

	if (strncmp(msg, initStr, strlen(initStr)) == 0) {
		DebugOutput("GUI-O app is requesting INITIALIZATION!\r\n");

		// Clear screen and set background
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@cls\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@guis BGC:#FFFFFF\r\n");
		// Initialize simple example GUI
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "|LB UID:title X:50 Y:15 TXT:\"Simple light switch\" FFA:\"font8\" FSZ:3.5\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "|LB UID:tap_me X:50 Y:70 TXT:\"TAP ME!\" FFA:\"font8\" FSZ:3 FFA:\"font5\"\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "|CB UID:brightness X:50 Y:50 W:90 BTH:5 HAH:8 HAW:8 VIS:0 STA:135 ENA:45 FGC:#000000 SFGC:#FFFF00 BGC:#CBCBCB\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "|IM UID:light_off X:50 Y:50 IP:\"https://i.imgur.com/3VbsS0Z.png\" VIS:1\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "|IM UID:light_on X:50 Y:50 IP:\"https://i.imgur.com/gNdck9A.png\" VIS:0\r\n");
	}
	else if (strncmp(msg, lightOffStr, strlen(lightOffStr)) == 0) {
		DebugOutput("GUI-O app is requesting LIGHT ON!\r\n");

		// "Drive GUI-O app"
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@light_off VIS:0\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@light_on VIS:1\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@brightness VIS:1 VAL:100\r\n");

		// LED enable
		SetLedBrightness(999);
		// NOTE: Built-in LED pins do not support PWM (use your own LED with resistor on PA0 pin)
		HAL_GPIO_WritePin(GPIOB, LED1_PIN, GPIO_PIN_SET);
	}
	else if (strncmp(msg, lightOnStr, strlen(lightOnStr)) == 0) {
		DebugOutput("GUI-O app is requesting LIGHT OFF!\r\n");

		// "Drive GUI-O app"
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@light_off VIS:1\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@light_on VIS:0\r\n");
		Custom_STM_App_Update_Char(CUSTOM_STM_TX, (uint8_t*) "@brightness VIS:0 VAL:0\r\n");

		// LED disable
		SetLedBrightness(0);
		// NOTE: Built-in LED pins do not support PWM (use your own LED with resistor on PA0 pin)
		HAL_GPIO_WritePin(GPIOB, LED1_PIN, GPIO_PIN_RESET);
	}
	else if (strncmp(msg, brightnessStr, strlen(brightnessStr)) == 0) {
		const char* idx = strchr(msg, ' ');

		if (idx == NULL)
			return;

		const int val = atoi(idx + 1);

		if (val >= 0 && val <= 100) {
			char buf[10];
			snprintf(buf, sizeof(buf), "%d", val);
			DebugOutput("GUI-O app is requesting LIGHT BRIGHTNESS: ");
			DebugOutput(buf);
			DebugOutput("\r\n");

			// LED drive
			SetLedBrightness(Remap(val, 0, 100, 1, 1000) - 1);
			// NOTE: Built-in LED pins do not support PWM (use your own LED with resistor on PA0 pin)
		}
	}
}
/* USER CODE END FD_LOCAL_FUNCTIONS*/
